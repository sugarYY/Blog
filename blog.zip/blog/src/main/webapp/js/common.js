//这个文件里放一些页面的公共代码

//加上一个逻辑，通过GET/login这个借口来获取下当前的登录状态
function getUserInfo(pageName){
    $.ajax({
        type:'get',
        url:'login',
        success: function(body){
            //判定此处的body是不是一个有效的user对象（userId是否非0）
            if(body.userId && body.userId > 0){
                //登陆成功不做处理

                //根据用户登陆情况，把当前用户名设置到界面上
                if(pageName == 'blog_list.html'){
                    changeUserName(body.username);
                }
            }else{
                alert("当前您尚未登录！请登录后再访问博客列表");
                location.assign('blog_login.html');
            }
        },
        error: function(){
            alert("当前您尚未登录！请登录后再访问博客列表");
            location.assign('blog_login.html');
        }
    });
}

function changeUserName(username){
    let h3 = document.querySelector('.card>h3');
    h3.innerHTML = username;
}