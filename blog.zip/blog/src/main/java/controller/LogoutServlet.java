package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * ClassName LogoutServlet
 * Description
 * Create by 93900
 * Date 2022/8/29 19:31
 */
@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        resp.setContentType("text/html; charset=utf8");

        if(session == null){
            //用户没有登录
            resp.getWriter().write("当前用户尚未登录，无法注销");
            return;
        }

        //把用户会话中的信息删除就行
        session.removeAttribute("user");
        resp.sendRedirect("blog_login.html");
    }


}
