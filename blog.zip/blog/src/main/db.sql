-- 编写建库建表的 sql

create database if not exists blog_sys;

use blog_sys;

-- 创建一个博客表
drop table if exists blog;
create table blog (
    blogId int primary key auto_increment,
    title varchar(1024),
    content mediumtext,
    userId int,
    postTime datetime
);

-- 给博客表插入数据，方便测试
insert into blog values(null, '这是第一篇博客', '从今天开始，我要认真学java', 1, now());
insert into blog values(null, '这是第二篇博客', '从今天开始，我要认真学java', 1, now());
insert into blog values(null, '这是第三篇博客', '从今天开始，我要认真学java', 1, now());
insert into blog values(null, '这是第一篇博客', '从今天开始，我要认真学java', 2, now());
insert into blog values(null, '这是第二篇博客', '从今天开始，我要认真学java', 2, now());
insert into blog values(null, '这是第三篇博客', '从今天开始，我要认真学java', 2, now());
insert into blog values(null, '这是第四篇博客', '从今天开始，我要认真学java', 2, now());

-- 创建一个用户表
drop table if exists user;
create table user(
    userId int primary key auto_increment,
    username varchar(128) unique,
    password varchar(128)
);

insert into user values(null, 'zhangsan', '123');
insert into user values(null, 'lisi', '123');
